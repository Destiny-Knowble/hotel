export const rooms = [
  {
    id: 1,
    name: "Deluxe Room",
    guests: 2,
    beds: "1 King Bed",
    size: "32m²",
    price: 120,
    img: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=600&q=80",
    desc: "A beautifully appointed room with garden views, premium linens, and curated amenities for ultimate comfort.",
  },
  {
    id: 2,
    name: "Executive Suite",
    guests: 2,
    beds: "1 King Bed",
    size: "60m²",
    price: 220,
    img: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=600&q=80",
    desc: "Spacious suite with separate living area, panoramic city views, and exclusive access to the Executive Lounge.",
  },
  {
    id: 3,
    name: "Family Suite",
    guests: 4,
    beds: "2 King Beds",
    size: "85m²",
    price: 320,
    img: "https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=600&q=80",
    desc: "Thoughtfully designed for families with two bedrooms, a shared lounge, and dedicated concierge service.",
  },
  {
    id: 4,
    name: "Presidential Villa",
    guests: 6,
    beds: "3 Bedrooms",
    size: "200m²",
    price: 950,
    img: "https://images.unsplash.com/photo-1560185007-cde436f6a4d0?w=600&q=80",
    desc: "The pinnacle of luxury — a private villa with a plunge pool, personal butler, and oceanfront terrace.",
  },
];

export const destinations = [
  {
    name: "Bora Bora",
    country: "French Polynesia",
    price: 320,
    img: "https://images.unsplash.com/photo-1589197331516-4d84b72ebde3?w=600&q=80",
  },
  {
    name: "Dubai",
    country: "United Arab Emirates",
    price: 180,
    img: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&q=80",
  },
  {
    name: "Santorini",
    country: "Greece",
    price: 240,
    img: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=600&q=80",
  },
  {
    name: "Maldives",
    country: "Indian Ocean",
    price: 410,
    img: "https://images.unsplash.com/photo-1540202404-a2f29016b523?w=600&q=80",
  },
  {
    name: "Machu Picchu",
    country: "Peru",
    price: 200,
    img: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?w=600&q=80",
  },
  {
    name: "Bali",
    country: "Indonesia",
    price: 150,
    img: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=600&q=80",
  },
];

export const reviews = [
  {
    name: "David Anderson",
    location: "London, UK",
    stars: 5,
    text: "Exceptional hospitality and beautiful property. Every little detail was perfectly taken care of.",
  },
  {
    name: "Sophia Martinez",
    location: "Dubai, UAE",
    stars: 5,
    text: "The best hotel I've ever stayed in. From the room to the food, everything was beyond amazing!",
  },
  {
    name: "Emma Brown",
    location: "Sydney, Australia",
    stars: 5,
    text: "Stunning views, luxurious rooms, and outstanding service. Highly recommended!",
  },
];

export const experiences = [
  {
    name: "Romantic Getaway",
    iconKey: "heart",
    desc: "Perfect escapes for couples — candlelit dinners, couples spa, sunset cruises.",
    price: 299,
  },
  {
    name: "Adventure & Activities",
    iconKey: "waves",
    desc: "Explore, discover, experience — diving, hiking, cultural tours and more.",
    price: 149,
  },
  {
    name: "Spa & Wellness",
    iconKey: "sparkles",
    desc: "Relax and rejuvenate your senses with world-class treatments.",
    price: 199,
  },
];
