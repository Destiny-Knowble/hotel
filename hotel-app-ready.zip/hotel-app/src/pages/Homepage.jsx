import { useState } from "react";
import {
  Trophy, RotateCcw, Diamond, MessageCircle,
  Tag, Coffee, TrendingUp, Clock,
  Heart, Waves, Sparkles, ArrowRight,
} from "lucide-react";
import COLORS from "../constants/colors";
import { rooms, destinations, reviews, experiences } from "../data/index";
import BookingBar from "../components/BookingBar";
import RoomCard from "../components/RoomCard";
import StarRating from "../components/StarRating";
import Footer from "../components/Footer";

const TABS = ["All Rooms", "Hotel Rooms", "Suites", "Villas", "Resorts"];

const TRUST_BADGES = [
  { icon: Trophy, title: "Best Price Guarantee", sub: "Get the best deal" },
  { icon: RotateCcw, title: "Flexible Cancellation", sub: "Plans that suit you" },
  { icon: Diamond, title: "Exclusive Offers", sub: "Save more on stays" },
  { icon: MessageCircle, title: "24/7 Support", sub: "We're here to help" },
];

const BENEFITS = [
  { icon: Tag, label: "Member Rates" },
  { icon: Coffee, label: "Free Breakfast" },
  { icon: TrendingUp, label: "Room Upgrade" },
  { icon: Clock, label: "Late Check-out" },
];

const EXPERIENCE_ICONS = {
  heart: Heart,
  waves: Waves,
  sparkles: Sparkles,
};

export default function HomePage({ onNavigate }) {
  const [activeTab, setActiveTab] = useState("All Rooms");

  const filtered =
    activeTab === "All Rooms"
      ? rooms
      : rooms.filter((r) => {
          if (activeTab === "Suites") return r.name.includes("Suite");
          if (activeTab === "Villas") return r.name.includes("Villa");
          return true;
        });

  return (
    <div style={{ background: COLORS.cream, minHeight: "100vh" }}>
      {/* ── Hero ── */}
      <div
        style={{
          position: "relative",
          height: "100vh",
          minHeight: 640,
          background: `linear-gradient(135deg, ${COLORS.forestDark} 0%, ${COLORS.forest} 60%, #2a6644 100%)`,
          display: "flex",
          alignItems: "center",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            opacity: 0.35,
            backgroundImage: `url(https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=1600&q=80)`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: `linear-gradient(to right, rgba(18,43,31,0.92) 0%, rgba(18,43,31,0.5) 60%, transparent 100%)`,
          }}
        />

        <div style={{ position: "relative", zIndex: 2, padding: "0 60px", maxWidth: 680 }}>
          <div style={{ color: COLORS.gold, fontSize: 11, letterSpacing: 4, marginBottom: 16 }}>
            PREMIUM HOTELS &amp; RESORTS
          </div>
          <h1
            style={{
              fontFamily: "Georgia, serif",
              color: COLORS.white,
              fontSize: "clamp(44px, 6vw, 80px)",
              lineHeight: 1.05,
              fontWeight: 400,
              margin: "0 0 12px",
            }}
          >
            Escape, Relax.
            <br />
            <span style={{ color: COLORS.gold }}>Experience More.</span>
          </h1>
          <p
            style={{
              color: "rgba(255,255,255,0.75)",
              fontSize: 16,
              lineHeight: 1.7,
              marginBottom: 40,
              maxWidth: 420,
            }}
          >
            Discover handpicked hotels and resorts offering exceptional comfort, warm hospitality,
            and unforgettable experiences.
          </p>

          <BookingBar onNavigate={onNavigate} />

          <div style={{ display: "flex", gap: 32, marginTop: 32, flexWrap: "wrap" }}>
            {TRUST_BADGES.map(({ icon: Icon, title, sub }) => (
              <div key={title} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Icon size={18} color={COLORS.goldLight} opacity={0.7} />
                <div>
                  <div style={{ color: COLORS.white, fontSize: 12, fontWeight: 600 }}>{title}</div>
                  <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>{sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Handpicked Stays ── */}
      <div style={{ padding: "80px 60px", maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <h2
            style={{
              fontFamily: "Georgia, serif",
              fontSize: 38,
              color: COLORS.textDark,
              fontWeight: 400,
              marginBottom: 8,
            }}
          >
            Our Handpicked Stays
          </h2>
          <p style={{ color: COLORS.textLight, fontSize: 15 }}>Comfort meets luxury in every detail</p>
        </div>

        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 40, flexWrap: "wrap" }}>
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              style={{
                background: activeTab === t ? COLORS.forest : "transparent",
                border: `1px solid ${activeTab === t ? COLORS.forest : "#ddd"}`,
                color: activeTab === t ? COLORS.white : COLORS.textMid,
                padding: "8px 20px",
                borderRadius: 40,
                cursor: "pointer",
                fontSize: 13,
                transition: "all 0.2s",
              }}
            >
              {t}
            </button>
          ))}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
            gap: 24,
          }}
        >
          {filtered.map((room) => (
            <RoomCard key={room.id} room={room} onNavigate={onNavigate} />
          ))}
        </div>

        <div style={{ textAlign: "center", marginTop: 40 }}>
          <button
            onClick={() => onNavigate("rooms")}
            style={{
              background: COLORS.forest,
              color: COLORS.white,
              border: "none",
              padding: "14px 40px",
              borderRadius: 4,
              fontSize: 13,
              fontWeight: 600,
              letterSpacing: 1.5,
              cursor: "pointer",
            }}
          >
            VIEW ALL ROOMS
          </button>
        </div>
      </div>

      {/* ── Promo Banner ── */}
      <div
        style={{
          margin: "0 60px 80px",
          borderRadius: 16,
          overflow: "hidden",
          position: "relative",
          minHeight: 240,
          display: "flex",
          alignItems: "center",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage: `url(https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1200&q=80)`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div style={{ position: "absolute", inset: 0, background: "rgba(18,43,31,0.85)" }} />
        <div style={{ position: "relative", zIndex: 1, padding: "40px 60px" }}>
          <div style={{ color: COLORS.goldLight, fontSize: 11, letterSpacing: 3, marginBottom: 8 }}>
            LIMITED TIME OFFER
          </div>
          <h2
            style={{
              fontFamily: "Georgia, serif",
              color: COLORS.white,
              fontSize: 36,
              fontWeight: 400,
              marginBottom: 12,
            }}
          >
            Save Up to 30%
            <br />
            on Selected Stays
          </h2>
          <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 14, marginBottom: 24 }}>
            Book now and enjoy exclusive discounts on luxury stays.
          </p>
          <button
            onClick={() => onNavigate("booking")}
            style={{
              background: "transparent",
              border: `1px solid ${COLORS.gold}`,
              color: COLORS.gold,
              padding: "12px 28px",
              borderRadius: 4,
              cursor: "pointer",
              fontSize: 13,
              fontWeight: 600,
              letterSpacing: 1,
            }}
          >
            EXPLORE OFFERS
          </button>
        </div>
      </div>

      {/* ── Popular Destinations ── */}
      <div style={{ padding: "0 60px 80px", maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <h2
            style={{
              fontFamily: "Georgia, serif",
              fontSize: 38,
              color: COLORS.textDark,
              fontWeight: 400,
              marginBottom: 8,
            }}
          >
            Popular Destinations
          </h2>
          <p style={{ color: COLORS.textLight }}>Explore breathtaking places</p>
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
            gap: 20,
          }}
        >
          {destinations.slice(0, 4).map((d) => (
            <div
              key={d.name}
              style={{
                borderRadius: 12,
                overflow: "hidden",
                position: "relative",
                height: 200,
                cursor: "pointer",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.querySelector("img").style.transform = "scale(1.05)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.querySelector("img").style.transform = "scale(1)")
              }
            >
              <img
                src={d.img}
                alt={d.name}
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  transition: "transform 0.4s ease",
                }}
              />
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 60%)",
                }}
              />
              <div style={{ position: "absolute", bottom: 16, left: 16 }}>
                <div style={{ color: COLORS.white, fontWeight: 600, fontSize: 15 }}>{d.name}</div>
                <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{d.country}</div>
                <div style={{ color: COLORS.gold, fontSize: 12, marginTop: 4 }}>
                  From ${d.price} / night
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Reviews ── */}
      <div style={{ background: COLORS.white, padding: "80px 60px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <h2
            style={{
              fontFamily: "Georgia, serif",
              fontSize: 38,
              color: COLORS.textDark,
              fontWeight: 400,
              textAlign: "center",
              marginBottom: 48,
            }}
          >
            What Our Guests Say
          </h2>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
              gap: 24,
            }}
          >
            {reviews.map((r) => (
              <div
                key={r.name}
                style={{
                  background: COLORS.cream,
                  borderRadius: 12,
                  padding: 28,
                  border: "1px solid #ece8df",
                }}
              >
                <StarRating count={r.stars} />
                <p
                  style={{
                    color: COLORS.textMid,
                    fontSize: 14,
                    lineHeight: 1.7,
                    margin: "16px 0",
                  }}
                >
                  "{r.text}"
                </p>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div
                    style={{
                      width: 42,
                      height: 42,
                      borderRadius: "50%",
                      background: COLORS.forest,
                      color: COLORS.white,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontWeight: 600,
                      fontSize: 14,
                    }}
                  >
                    {r.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.textDark }}>
                      {r.name}
                    </div>
                    <div style={{ fontSize: 12, color: COLORS.textLight }}>{r.location}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Experiences ── */}
      <div style={{ padding: "80px 60px", background: COLORS.cream }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <h2
              style={{
                fontFamily: "Georgia, serif",
                fontSize: 38,
                color: COLORS.textDark,
                fontWeight: 400,
                marginBottom: 8,
              }}
            >
              Unique Experiences
            </h2>
            <p style={{ color: COLORS.textLight }}>Make your stay unforgettable</p>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
              gap: 24,
            }}
          >
            {experiences.map((exp) => {
              const Icon = EXPERIENCE_ICONS[exp.iconKey] || Diamond;
              return (
                <div
                  key={exp.name}
                  style={{
                    background: COLORS.white,
                    borderRadius: 12,
                    padding: 32,
                    border: "1px solid #eee",
                    cursor: "pointer",
                    transition: "transform 0.2s",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-4px)")}
                  onMouseLeave={(e) => (e.currentTarget.style.transform = "none")}
                >
                  <div
                    style={{
                      width: 56,
                      height: 56,
                      borderRadius: 12,
                      background: `${COLORS.forest}15`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      marginBottom: 16,
                    }}
                  >
                    <Icon size={26} color={COLORS.forest} />
                  </div>
                  <h3
                    style={{
                      fontFamily: "Georgia, serif",
                      fontSize: 20,
                      color: COLORS.textDark,
                      marginBottom: 12,
                    }}
                  >
                    {exp.name}
                  </h3>
                  <p style={{ color: COLORS.textMid, fontSize: 14, lineHeight: 1.7, marginBottom: 20 }}>
                    {exp.desc}
                  </p>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ color: COLORS.forest, fontWeight: 600, fontSize: 18 }}>
                      from ${exp.price}
                    </span>
                    <span style={{ color: COLORS.forest, fontSize: 13, fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}>
                      View Details <ArrowRight size={13} />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Exclusive Benefits ── */}
      <div style={{ background: COLORS.forestDark, padding: "80px 60px" }}>
        <div
          style={{
            maxWidth: 1200,
            margin: "0 auto",
            display: "flex",
            gap: 60,
            alignItems: "center",
            flexWrap: "wrap",
          }}
        >
          <div style={{ flex: "0 0 280px" }}>
            <div style={{ color: COLORS.gold, fontSize: 11, letterSpacing: 3, marginBottom: 12 }}>
              DIRECT BOOKING PERKS
            </div>
            <h2
              style={{
                fontFamily: "Georgia, serif",
                color: COLORS.white,
                fontSize: 32,
                fontWeight: 400,
                marginBottom: 16,
              }}
            >
              Exclusive Benefits Just for You
            </h2>
            <p
              style={{
                color: "rgba(255,255,255,0.65)",
                fontSize: 14,
                lineHeight: 1.7,
                marginBottom: 28,
              }}
            >
              Book directly on our website and unlock exclusive perks and savings.
            </p>
            <button
              onClick={() => onNavigate("booking")}
              style={{
                background: "transparent",
                border: `1px solid ${COLORS.gold}`,
                color: COLORS.gold,
                padding: "12px 28px",
                borderRadius: 4,
                cursor: "pointer",
                fontSize: 13,
                letterSpacing: 1,
              }}
            >
              LEARN MORE
            </button>
          </div>

          <div
            style={{
              flex: 1,
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 16,
            }}
          >
            {BENEFITS.map(({ icon: Icon, label }) => (
              <div
                key={label}
                style={{
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(201,168,76,0.2)",
                  borderRadius: 8,
                  padding: "24px",
                  display: "flex",
                  alignItems: "center",
                  gap: 16,
                }}
              >
                <Icon size={26} color={COLORS.gold} />
                <span style={{ color: COLORS.white, fontSize: 14, fontWeight: 500 }}>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Newsletter ── */}
      <div style={{ background: COLORS.white, padding: "80px 60px" }}>
        <div style={{ maxWidth: 600, margin: "0 auto", textAlign: "center" }}>
          <h2
            style={{
              fontFamily: "Georgia, serif",
              fontSize: 32,
              color: COLORS.textDark,
              fontWeight: 400,
              marginBottom: 12,
            }}
          >
            Subscribe to Our Newsletter
          </h2>
          <p style={{ color: COLORS.textLight, marginBottom: 32 }}>
            Get exclusive offers and travel inspiration
          </p>
          <div style={{ display: "flex", gap: 8, maxWidth: 440, margin: "0 auto" }}>
            <input
              type="email"
              placeholder="Enter your email address"
              style={{
                flex: 1,
                padding: "12px 16px",
                border: "1px solid #ddd",
                borderRadius: 4,
                fontSize: 14,
                outline: "none",
              }}
            />
            <button
              style={{
                background: COLORS.forest,
                color: COLORS.white,
                border: "none",
                padding: "12px 24px",
                borderRadius: 4,
                cursor: "pointer",
                fontSize: 13,
                fontWeight: 600,
                letterSpacing: 1,
              }}
            >
              SUBSCRIBE
            </button>
          </div>
        </div>
      </div>

      <Footer onNavigate={onNavigate} />
    </div>
  );
}
