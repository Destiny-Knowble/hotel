import { Users, BedDouble, Maximize2, ArrowRight } from "lucide-react";
import COLORS from "../constants/colors";

export default function RoomCard({ room, onNavigate }) {
  return (
    <div
      onClick={() => onNavigate("room-" + room.id)}
      style={{
        background: COLORS.white,
        borderRadius: 12,
        overflow: "hidden",
        border: "1px solid #eee",
        cursor: "pointer",
        transition: "transform 0.2s, box-shadow 0.2s",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-4px)";
        e.currentTarget.style.boxShadow = "0 12px 40px rgba(0,0,0,0.12)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "none";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <div style={{ position: "relative", height: 200, overflow: "hidden" }}>
        <img
          src={room.img}
          alt={room.name}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
        <div
          style={{
            position: "absolute",
            top: 12,
            right: 12,
            background: COLORS.gold,
            color: COLORS.forestDark,
            padding: "4px 10px",
            borderRadius: 4,
            fontSize: 11,
            fontWeight: 700,
          }}
        >
          FROM ${room.price}/night
        </div>
      </div>

      <div style={{ padding: "20px" }}>
        <h3 style={{ fontSize: 17, fontWeight: 600, color: COLORS.textDark, marginBottom: 8 }}>
          {room.name}
        </h3>
        <div style={{ display: "flex", gap: 16, marginBottom: 12, flexWrap: "wrap" }}>
          <span style={{ fontSize: 12, color: COLORS.textLight, display: "flex", alignItems: "center", gap: 4 }}>
            <Users size={12} /> {room.guests}
          </span>
          <span style={{ fontSize: 12, color: COLORS.textLight, display: "flex", alignItems: "center", gap: 4 }}>
            <BedDouble size={12} /> {room.beds}
          </span>
          <span style={{ fontSize: 12, color: COLORS.textLight, display: "flex", alignItems: "center", gap: 4 }}>
            <Maximize2 size={12} /> {room.size}
          </span>
        </div>
        <p style={{ fontSize: 13, color: COLORS.textMid, lineHeight: 1.6, marginBottom: 16 }}>
          {room.desc.slice(0, 80)}...
        </p>
        <div style={{ color: COLORS.forest, fontSize: 13, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>
          View Details <ArrowRight size={13} />
        </div>
      </div>
    </div>
  );
}
