import { Star } from "lucide-react";
import COLORS from "../constants/colors";

export default function StarRating({ count = 5 }) {
  return (
    <div style={{ display: "flex", gap: 2 }}>
      {[...Array(count)].map((_, i) => (
        <Star key={i} size={14} fill={COLORS.gold} color={COLORS.gold} />
      ))}
    </div>
  );
}
