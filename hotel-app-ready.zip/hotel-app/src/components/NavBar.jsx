import { useState, useEffect } from "react";
import { Menu, X, Phone, Diamond } from "lucide-react";
import COLORS from "../constants/colors";

const NAV_LINKS = ["Rooms", "Offers", "Dining", "Destinations", "About"];

export default function NavBar({ onNavigate, page }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 1000,
          background: scrolled
            ? "rgba(26,61,46,0.97)"
            : "rgba(26,61,46,0.85)",
          backdropFilter: "blur(12px)",
          borderBottom: scrolled
            ? "1px solid rgba(201,168,76,0.2)"
            : "none",
          transition: "all 0.3s ease",
          padding: "0 24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 64,
        }}
      >
        {/* Logo */}
        <div
          onClick={() => onNavigate("home")}
          style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}
        >
          <Diamond size={18} color={COLORS.gold} fill={COLORS.gold} />
          <div>
            <div
              style={{
                fontFamily: "Georgia, serif",
                color: COLORS.white,
                fontSize: 17,
                letterSpacing: 2,
                fontWeight: 600,
              }}
            >
              ACZONE
            </div>
            <div
              style={{
                color: COLORS.goldLight,
                fontSize: 8,
                letterSpacing: 3,
                opacity: 0.8,
              }}
            >
              HOTELS &amp; RESORTS
            </div>
          </div>
        </div>

        {/* Desktop Links */}
        <div style={{ display: "flex", gap: 32, alignItems: "center" }}>
          {NAV_LINKS.map((link) => (
            <button
              key={link}
              onClick={() => onNavigate(link.toLowerCase())}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                color: COLORS.white,
                fontSize: 13,
                letterSpacing: 1,
                opacity: 0.85,
                padding: "4px 0",
                borderBottom:
                  page === link.toLowerCase()
                    ? `1px solid ${COLORS.gold}`
                    : "1px solid transparent",
                transition: "all 0.2s",
              }}
            >
              {link}
            </button>
          ))}
        </div>

        {/* Actions */}
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5, color: COLORS.goldLight, fontSize: 12, opacity: 0.8 }}>
            <Phone size={11} />
            +123 456 7890
          </div>
          <button
            onClick={() => onNavigate("booking")}
            style={{
              background: COLORS.gold,
              border: "none",
              cursor: "pointer",
              color: COLORS.forestDark,
              fontWeight: 700,
              fontSize: 12,
              letterSpacing: 1.5,
              padding: "10px 20px",
              borderRadius: 4,
              transition: "background 0.2s",
            }}
          >
            BOOK NOW
          </button>
          <button
            onClick={() => setMenuOpen(true)}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: COLORS.white,
              padding: 4,
              display: "none",
            }}
            className="mobile-menu-btn"
          >
            <Menu size={22} />
          </button>
        </div>
      </nav>

      {/* Mobile Overlay */}
      <div
        onClick={() => setMenuOpen(false)}
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 1100,
          background: "rgba(0,0,0,0.6)",
          opacity: menuOpen ? 1 : 0,
          pointerEvents: menuOpen ? "all" : "none",
          transition: "opacity 0.3s ease",
        }}
      />

      {/* Mobile Drawer */}
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          bottom: 0,
          width: 280,
          zIndex: 1200,
          background: COLORS.forestDark,
          transform: menuOpen ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 0.35s cubic-bezier(0.4,0,0.2,1)",
          display: "flex",
          flexDirection: "column",
          padding: 24,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 40,
          }}
        >
          <div
            style={{
              fontFamily: "Georgia, serif",
              color: COLORS.gold,
              fontSize: 18,
              letterSpacing: 2,
            }}
          >
            ACZONE
          </div>
          <button
            onClick={() => setMenuOpen(false)}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: COLORS.white,
              padding: 4,
            }}
          >
            <X size={20} />
          </button>
        </div>

        {NAV_LINKS.map((link) => (
          <button
            key={link}
            onClick={() => {
              setMenuOpen(false);
              onNavigate(link.toLowerCase());
            }}
            style={{
              background: "none",
              border: "none",
              borderBottom: `1px solid rgba(255,255,255,0.08)`,
              cursor: "pointer",
              color: COLORS.white,
              fontSize: 15,
              textAlign: "left",
              padding: "18px 0",
              letterSpacing: 1,
            }}
          >
            {link}
          </button>
        ))}

        <button
          onClick={() => {
            setMenuOpen(false);
            onNavigate("booking");
          }}
          style={{
            background: COLORS.gold,
            border: "none",
            cursor: "pointer",
            color: COLORS.forestDark,
            fontWeight: 700,
            fontSize: 13,
            letterSpacing: 1.5,
            padding: "14px",
            borderRadius: 4,
            marginTop: 32,
            textAlign: "center",
          }}
        >
          BOOK NOW
        </button>
      </div>
    </>
  );
}
