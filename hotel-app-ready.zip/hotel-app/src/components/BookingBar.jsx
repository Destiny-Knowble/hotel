import { useState } from "react";
import { CalendarCheck, CalendarX, Users } from "lucide-react";
import COLORS from "../constants/colors";

const GUEST_OPTIONS = [
  "1 Adult",
  "2 Adults",
  "2 Adults, 1 Child",
  "2 Adults, 2 Children",
  "3 Adults",
];

export default function BookingBar({ onNavigate }) {
  const [checkin, setCheckin] = useState("2024-05-18");
  const [checkout, setCheckout] = useState("2024-05-21");
  const [guests, setGuests] = useState("2 Adults");

  const inputStyle = {
    background: "rgba(255,255,255,0.08)",
    border: "1px solid rgba(201,168,76,0.3)",
    color: COLORS.white,
    padding: "10px 12px",
    borderRadius: 4,
    width: "100%",
    fontSize: 13,
    outline: "none",
    boxSizing: "border-box",
  };

  const labelStyle = {
    color: COLORS.goldLight,
    fontSize: 10,
    letterSpacing: 2,
    marginBottom: 6,
    display: "flex",
    alignItems: "center",
    gap: 5,
  };

  return (
    <div
      style={{
        background: COLORS.forestDark,
        borderRadius: 8,
        padding: "20px 24px",
        display: "flex",
        gap: 16,
        alignItems: "flex-end",
        flexWrap: "wrap",
      }}
    >
      {/* Check-in */}
      <div style={{ flex: 1, minWidth: 140 }}>
        <div style={labelStyle}>
          <CalendarCheck size={11} />
          CHECK-IN
        </div>
        <input
          type="date"
          value={checkin}
          onChange={(e) => setCheckin(e.target.value)}
          style={inputStyle}
        />
      </div>

      {/* Check-out */}
      <div style={{ flex: 1, minWidth: 140 }}>
        <div style={labelStyle}>
          <CalendarX size={11} />
          CHECK-OUT
        </div>
        <input
          type="date"
          value={checkout}
          onChange={(e) => setCheckout(e.target.value)}
          style={inputStyle}
        />
      </div>

      {/* Guests */}
      <div style={{ flex: 1, minWidth: 160 }}>
        <div style={labelStyle}>
          <Users size={11} />
          GUESTS
        </div>
        <select
          value={guests}
          onChange={(e) => setGuests(e.target.value)}
          style={inputStyle}
        >
          {GUEST_OPTIONS.map((o) => (
            <option key={o} value={o} style={{ background: COLORS.forestDark }}>
              {o}
            </option>
          ))}
        </select>
      </div>

      <button
        onClick={() => onNavigate("booking")}
        style={{
          background: COLORS.gold,
          border: "none",
          cursor: "pointer",
          color: COLORS.forestDark,
          fontWeight: 700,
          fontSize: 12,
          letterSpacing: 1.5,
          padding: "12px 28px",
          borderRadius: 4,
          whiteSpace: "nowrap",
        }}
      >
        CHECK AVAILABILITY
      </button>
    </div>
  );
}
