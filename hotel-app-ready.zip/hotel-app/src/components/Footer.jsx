import { Share2, Globe, X, AtSign, Diamond, Phone, Mail, MapPin } from "lucide-react";
import COLORS from "../constants/colors";

const FOOTER_COLUMNS = [
  { title: "Company", links: ["About Us", "Careers", "News", "Blog", "Contact"] },
  { title: "Support", links: ["Help Center", "FAQs", "Terms & Conditions", "Privacy Policy"] },
  { title: "Quick Links", links: ["Rooms", "Offers", "Dining", "Destinations", "Gallery"] },
];

const SOCIAL_ICONS = [
  { icon: Share2, label: "Facebook" },
  { icon: Globe, label: "LinkedIn" },
  { icon: X, label: "X / Twitter" },
  { icon: AtSign, label: "Instagram" },
];

const CONTACT_ITEMS = [
  { icon: Phone, text: "+123 456 7890" },
  { icon: Mail, text: "info@aczone.com" },
  { icon: MapPin, text: "123 Paradise Ave, New York, USA" },
];

export default function Footer({ onNavigate }) {
  return (
    <footer style={{ background: COLORS.forestDark, padding: "60px", color: "rgba(255,255,255,0.7)" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "2fr 1fr 1fr 1fr 1.5fr",
            gap: 40,
            marginBottom: 40,
          }}
        >
          {/* Brand */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
              <Diamond size={18} color={COLORS.gold} fill={COLORS.gold} />
              <div>
                <div
                  style={{
                    fontFamily: "Georgia, serif",
                    color: COLORS.white,
                    fontSize: 16,
                    letterSpacing: 2,
                  }}
                >
                  ACZONE
                </div>
                <div style={{ color: COLORS.goldLight, fontSize: 8, letterSpacing: 3 }}>
                  HOTELS &amp; RESORTS
                </div>
              </div>
            </div>
            <p
              style={{
                fontSize: 13,
                lineHeight: 1.8,
                maxWidth: 240,
                marginBottom: 20,
              }}
            >
              Experience the perfect blend of luxury, comfort, and hospitality. We make every stay memorable.
            </p>
            <div style={{ display: "flex", gap: 12 }}>
              {SOCIAL_ICONS.map(({ icon: Icon, label }) => (
                <div
                  key={label}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: "50%",
                    background: "rgba(255,255,255,0.1)",
                    border: "1px solid rgba(255,255,255,0.2)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                  }}
                >
                  <Icon size={13} color={COLORS.white} />
                </div>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {FOOTER_COLUMNS.map((col) => (
            <div key={col.title}>
              <div
                style={{
                  color: COLORS.white,
                  fontWeight: 600,
                  fontSize: 13,
                  letterSpacing: 1,
                  marginBottom: 16,
                }}
              >
                {col.title}
              </div>
              {col.links.map((link) => (
                <div
                  key={link}
                  style={{
                    fontSize: 13,
                    marginBottom: 10,
                    cursor: "pointer",
                    opacity: 0.7,
                    lineHeight: 1.5,
                  }}
                >
                  {link}
                </div>
              ))}
            </div>
          ))}

          {/* Contact column */}
          <div>
            <div
              style={{
                color: COLORS.white,
                fontWeight: 600,
                fontSize: 13,
                letterSpacing: 1,
                marginBottom: 16,
              }}
            >
              Contact Us
            </div>
            {CONTACT_ITEMS.map(({ icon: Icon, text }) => (
              <div
                key={text}
                style={{
                  fontSize: 13,
                  marginBottom: 12,
                  opacity: 0.7,
                  display: "flex",
                  alignItems: "flex-start",
                  gap: 8,
                  lineHeight: 1.5,
                }}
              >
                <Icon size={13} style={{ marginTop: 2, flexShrink: 0 }} />
                {text}
              </div>
            ))}
          </div>
        </div>

        <div
          style={{
            borderTop: "1px solid rgba(255,255,255,0.1)",
            paddingTop: 24,
            textAlign: "center",
            fontSize: 12,
            opacity: 0.5,
          }}
        >
          © 2024 Aczone Hotels &amp; Resorts. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
