import { useState } from "react";
import NavBar from "./components/NavBar";
import HomePage from "./pages/Homepage";

export default function App() {
  const [page, setPage] = useState("home");

  const handleNavigate = (target) => {
    setPage(target);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const renderPage = () => {
    switch (page) {
      case "home":
        return <HomePage onNavigate={handleNavigate} />;
      default:
        return (
          <div
            style={{
              minHeight: "100vh",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
              gap: 16,
              fontFamily: "Georgia, serif",
              background: "#f8f5ef",
            }}
          >
            <h2 style={{ fontSize: 32, color: "#1a3d2e" }}>
              {page.charAt(0).toUpperCase() + page.slice(1)}
            </h2>
            <p style={{ color: "#888", fontSize: 15 }}>This page is coming soon.</p>
            <button
              onClick={() => handleNavigate("home")}
              style={{
                background: "#1a3d2e",
                color: "#fff",
                border: "none",
                padding: "12px 32px",
                borderRadius: 4,
                cursor: "pointer",
                fontSize: 13,
                letterSpacing: 1,
                marginTop: 8,
              }}
            >
              ← BACK TO HOME
            </button>
          </div>
        );
    }
  };

  return (
    <>
      <NavBar onNavigate={handleNavigate} page={page} />
      <div style={{ paddingTop: page === "home" ? 0 : 64 }}>{renderPage()}</div>
    </>
  );
}
