const COLORS = {
  forest: "#1a3d2e",
  forestDark: "#122b1f",
  forestLight: "#2a5c44",
  gold: "#c9a84c",
  goldLight: "#e2c27a",
  cream: "#f8f5ef",
  creamDark: "#f0ebe0",
  white: "#ffffff",
  textDark: "#1a1a1a",
  textMid: "#4a4a4a",
  textLight: "#888",
};

export default COLORS;
